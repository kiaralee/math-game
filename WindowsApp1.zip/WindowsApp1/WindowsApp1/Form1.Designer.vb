﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.LblAnswer1 = New System.Windows.Forms.Label()
        Me.LblAnswer2 = New System.Windows.Forms.Label()
        Me.LblQuestion = New System.Windows.Forms.Label()
        Me.LblPlayer = New System.Windows.Forms.Label()
        Me.LblAlien = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ProgBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LblAnswer3 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LblPrev = New System.Windows.Forms.Label()
        Me.LblLevel = New System.Windows.Forms.Label()
        Me.PbAlien = New System.Windows.Forms.PictureBox()
        Me.PbPlayer = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.LblDialog = New System.Windows.Forms.Label()
        Me.LblStreak = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BPPlayer = New System.Windows.Forms.ProgressBar()
        Me.BPAlien = New System.Windows.Forms.ProgressBar()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LblLives = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblPause = New System.Windows.Forms.Label()
        Me.PanelPause = New System.Windows.Forms.Panel()
        Me.LblExtra = New System.Windows.Forms.Label()
        Me.LblRestart = New System.Windows.Forms.Label()
        Me.LblResume = New System.Windows.Forms.Label()
        Me.LblGP = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblClose = New System.Windows.Forms.Label()
        Me.LblWin = New System.Windows.Forms.Label()
        Me.LblMenu = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PbAlien, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelPause.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblAnswer1
        '
        Me.LblAnswer1.BackColor = System.Drawing.Color.Transparent
        Me.LblAnswer1.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAnswer1.Location = New System.Drawing.Point(12, 40)
        Me.LblAnswer1.Name = "LblAnswer1"
        Me.LblAnswer1.Size = New System.Drawing.Size(106, 38)
        Me.LblAnswer1.TabIndex = 0
        Me.LblAnswer1.Text = "25"
        Me.LblAnswer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblAnswer1.Visible = False
        '
        'LblAnswer2
        '
        Me.LblAnswer2.BackColor = System.Drawing.Color.Transparent
        Me.LblAnswer2.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAnswer2.Location = New System.Drawing.Point(20, 46)
        Me.LblAnswer2.Name = "LblAnswer2"
        Me.LblAnswer2.Size = New System.Drawing.Size(111, 38)
        Me.LblAnswer2.TabIndex = 1
        Me.LblAnswer2.Text = "25"
        Me.LblAnswer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblAnswer2.Visible = False
        '
        'LblQuestion
        '
        Me.LblQuestion.BackColor = System.Drawing.Color.Transparent
        Me.LblQuestion.Font = New System.Drawing.Font("Verdana", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblQuestion.ForeColor = System.Drawing.Color.White
        Me.LblQuestion.Location = New System.Drawing.Point(344, 12)
        Me.LblQuestion.Name = "LblQuestion"
        Me.LblQuestion.Size = New System.Drawing.Size(513, 59)
        Me.LblQuestion.TabIndex = 3
        Me.LblQuestion.Text = "5 x 5"
        Me.LblQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblQuestion.Visible = False
        '
        'LblPlayer
        '
        Me.LblPlayer.AutoSize = True
        Me.LblPlayer.BackColor = System.Drawing.Color.Transparent
        Me.LblPlayer.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPlayer.ForeColor = System.Drawing.Color.White
        Me.LblPlayer.Location = New System.Drawing.Point(380, 461)
        Me.LblPlayer.Name = "LblPlayer"
        Me.LblPlayer.Size = New System.Drawing.Size(58, 29)
        Me.LblPlayer.TabIndex = 5
        Me.LblPlayer.Text = "100"
        Me.LblPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblAlien
        '
        Me.LblAlien.AutoSize = True
        Me.LblAlien.BackColor = System.Drawing.Color.Transparent
        Me.LblAlien.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAlien.ForeColor = System.Drawing.Color.White
        Me.LblAlien.Location = New System.Drawing.Point(779, 461)
        Me.LblAlien.Name = "LblAlien"
        Me.LblAlien.Size = New System.Drawing.Size(58, 29)
        Me.LblAlien.TabIndex = 6
        Me.LblAlien.Text = "100"
        Me.LblAlien.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(530, 461)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(148, 29)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Brainpower"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProgBar1
        '
        Me.ProgBar1.BackColor = System.Drawing.SystemColors.Control
        Me.ProgBar1.ForeColor = System.Drawing.Color.DarkRed
        Me.ProgBar1.Location = New System.Drawing.Point(96, 57)
        Me.ProgBar1.Name = "ProgBar1"
        Me.ProgBar1.Size = New System.Drawing.Size(156, 23)
        Me.ProgBar1.Step = 5
        Me.ProgBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgBar1.TabIndex = 11
        Me.ProgBar1.Value = 100
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(8, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 29)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Time:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.star2
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.LblAnswer1)
        Me.Panel1.Location = New System.Drawing.Point(284, 93)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(138, 125)
        Me.Panel1.TabIndex = 16
        '
        'LblAnswer3
        '
        Me.LblAnswer3.BackColor = System.Drawing.Color.Transparent
        Me.LblAnswer3.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAnswer3.Location = New System.Drawing.Point(20, 46)
        Me.LblAnswer3.Name = "LblAnswer3"
        Me.LblAnswer3.Size = New System.Drawing.Size(111, 38)
        Me.LblAnswer3.TabIndex = 2
        Me.LblAnswer3.Text = "25"
        Me.LblAnswer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblAnswer3.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.star1
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.LblAnswer2)
        Me.Panel2.Location = New System.Drawing.Point(527, 93)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(149, 125)
        Me.Panel2.TabIndex = 17
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.star3
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.LblAnswer3)
        Me.Panel3.Location = New System.Drawing.Point(776, 93)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(145, 125)
        Me.Panel3.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(8, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(183, 29)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Last question:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(1085, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 29)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Level:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPrev
        '
        Me.LblPrev.AutoSize = True
        Me.LblPrev.BackColor = System.Drawing.Color.Transparent
        Me.LblPrev.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPrev.ForeColor = System.Drawing.Color.White
        Me.LblPrev.Location = New System.Drawing.Point(197, 12)
        Me.LblPrev.Name = "LblPrev"
        Me.LblPrev.Size = New System.Drawing.Size(55, 29)
        Me.LblPrev.TabIndex = 22
        Me.LblPrev.Text = "xxx"
        Me.LblPrev.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblLevel
        '
        Me.LblLevel.BackColor = System.Drawing.Color.Transparent
        Me.LblLevel.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLevel.ForeColor = System.Drawing.Color.White
        Me.LblLevel.Location = New System.Drawing.Point(1166, 11)
        Me.LblLevel.Name = "LblLevel"
        Me.LblLevel.Size = New System.Drawing.Size(52, 31)
        Me.LblLevel.TabIndex = 23
        Me.LblLevel.Text = "1"
        Me.LblLevel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PbAlien
        '
        Me.PbAlien.BackColor = System.Drawing.Color.Transparent
        Me.PbAlien.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.alien1
        Me.PbAlien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PbAlien.Location = New System.Drawing.Point(863, 246)
        Me.PbAlien.Name = "PbAlien"
        Me.PbAlien.Size = New System.Drawing.Size(307, 300)
        Me.PbAlien.TabIndex = 24
        Me.PbAlien.TabStop = False
        '
        'PbPlayer
        '
        Me.PbPlayer.BackColor = System.Drawing.Color.Transparent
        Me.PbPlayer.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.spaceman
        Me.PbPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PbPlayer.Location = New System.Drawing.Point(124, 202)
        Me.PbPlayer.Name = "PbPlayer"
        Me.PbPlayer.Size = New System.Drawing.Size(231, 328)
        Me.PbPlayer.TabIndex = 25
        Me.PbPlayer.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.LblDialog)
        Me.Panel4.Location = New System.Drawing.Point(185, 552)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(861, 58)
        Me.Panel4.TabIndex = 26
        '
        'LblDialog
        '
        Me.LblDialog.BackColor = System.Drawing.Color.Transparent
        Me.LblDialog.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDialog.ForeColor = System.Drawing.Color.White
        Me.LblDialog.Location = New System.Drawing.Point(-1, 6)
        Me.LblDialog.Name = "LblDialog"
        Me.LblDialog.Size = New System.Drawing.Size(855, 45)
        Me.LblDialog.TabIndex = 2
        Me.LblDialog.Text = "25"
        Me.LblDialog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblStreak
        '
        Me.LblStreak.BackColor = System.Drawing.Color.Transparent
        Me.LblStreak.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblStreak.ForeColor = System.Drawing.Color.White
        Me.LblStreak.Location = New System.Drawing.Point(119, 549)
        Me.LblStreak.Name = "LblStreak"
        Me.LblStreak.Size = New System.Drawing.Size(52, 31)
        Me.LblStreak.TabIndex = 28
        Me.LblStreak.Text = "0"
        Me.LblStreak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(12, 549)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 29)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "Streak:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BPPlayer
        '
        Me.BPPlayer.BackColor = System.Drawing.SystemColors.Control
        Me.BPPlayer.ForeColor = System.Drawing.Color.DarkRed
        Me.BPPlayer.Location = New System.Drawing.Point(377, 498)
        Me.BPPlayer.Name = "BPPlayer"
        Me.BPPlayer.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.BPPlayer.RightToLeftLayout = True
        Me.BPPlayer.Size = New System.Drawing.Size(229, 23)
        Me.BPPlayer.Step = 5
        Me.BPPlayer.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.BPPlayer.TabIndex = 30
        Me.BPPlayer.Value = 100
        '
        'BPAlien
        '
        Me.BPAlien.BackColor = System.Drawing.SystemColors.Control
        Me.BPAlien.ForeColor = System.Drawing.Color.DarkRed
        Me.BPAlien.Location = New System.Drawing.Point(606, 498)
        Me.BPAlien.Name = "BPAlien"
        Me.BPAlien.Size = New System.Drawing.Size(231, 23)
        Me.BPAlien.Step = 5
        Me.BPAlien.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.BPAlien.TabIndex = 31
        Me.BPAlien.Value = 100
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.spaceman
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(124, 202)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(231, 328)
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'LblLives
        '
        Me.LblLives.BackColor = System.Drawing.Color.Transparent
        Me.LblLives.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLives.ForeColor = System.Drawing.Color.White
        Me.LblLives.Location = New System.Drawing.Point(119, 579)
        Me.LblLives.Name = "LblLives"
        Me.LblLives.Size = New System.Drawing.Size(52, 31)
        Me.LblLives.TabIndex = 33
        Me.LblLives.Text = "3"
        Me.LblLives.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(12, 579)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 29)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Lives:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPause
        '
        Me.LblPause.AutoSize = True
        Me.LblPause.BackColor = System.Drawing.Color.Transparent
        Me.LblPause.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPause.ForeColor = System.Drawing.Color.White
        Me.LblPause.Location = New System.Drawing.Point(1088, 567)
        Me.LblPause.Name = "LblPause"
        Me.LblPause.Size = New System.Drawing.Size(82, 29)
        Me.LblPause.TabIndex = 34
        Me.LblPause.Text = "Pause"
        Me.LblPause.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelPause
        '
        Me.PanelPause.BackColor = System.Drawing.Color.Black
        Me.PanelPause.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PanelPause.Controls.Add(Me.LblMenu)
        Me.PanelPause.Controls.Add(Me.LblWin)
        Me.PanelPause.Controls.Add(Me.LblClose)
        Me.PanelPause.Controls.Add(Me.Label2)
        Me.PanelPause.Controls.Add(Me.LblExtra)
        Me.PanelPause.Controls.Add(Me.LblRestart)
        Me.PanelPause.Controls.Add(Me.LblResume)
        Me.PanelPause.Controls.Add(Me.LblGP)
        Me.PanelPause.Location = New System.Drawing.Point(284, 51)
        Me.PanelPause.Name = "PanelPause"
        Me.PanelPause.Size = New System.Drawing.Size(637, 495)
        Me.PanelPause.TabIndex = 35
        Me.PanelPause.Visible = False
        '
        'LblExtra
        '
        Me.LblExtra.BackColor = System.Drawing.Color.Black
        Me.LblExtra.Font = New System.Drawing.Font("Verdana", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblExtra.ForeColor = System.Drawing.Color.White
        Me.LblExtra.Location = New System.Drawing.Point(11, 299)
        Me.LblExtra.Name = "LblExtra"
        Me.LblExtra.Size = New System.Drawing.Size(607, 43)
        Me.LblExtra.TabIndex = 39
        Me.LblExtra.Text = "HELP"
        Me.LblExtra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblExtra.Visible = False
        '
        'LblRestart
        '
        Me.LblRestart.BackColor = System.Drawing.Color.Black
        Me.LblRestart.Font = New System.Drawing.Font("Verdana", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRestart.ForeColor = System.Drawing.Color.White
        Me.LblRestart.Location = New System.Drawing.Point(11, 256)
        Me.LblRestart.Name = "LblRestart"
        Me.LblRestart.Size = New System.Drawing.Size(607, 43)
        Me.LblRestart.TabIndex = 38
        Me.LblRestart.Text = "BEGIN HARD GAME"
        Me.LblRestart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblRestart.Visible = False
        '
        'LblResume
        '
        Me.LblResume.BackColor = System.Drawing.Color.Black
        Me.LblResume.Font = New System.Drawing.Font("Verdana", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblResume.ForeColor = System.Drawing.Color.White
        Me.LblResume.Location = New System.Drawing.Point(11, 213)
        Me.LblResume.Name = "LblResume"
        Me.LblResume.Size = New System.Drawing.Size(607, 43)
        Me.LblResume.TabIndex = 37
        Me.LblResume.Text = "BEGIN EASY GAME"
        Me.LblResume.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblResume.Visible = False
        '
        'LblGP
        '
        Me.LblGP.BackColor = System.Drawing.Color.Black
        Me.LblGP.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblGP.ForeColor = System.Drawing.Color.White
        Me.LblGP.Location = New System.Drawing.Point(-2, 149)
        Me.LblGP.Name = "LblGP"
        Me.LblGP.Size = New System.Drawing.Size(634, 55)
        Me.LblGP.TabIndex = 36
        Me.LblGP.Text = "MULTIPLICATION DEFENDERS!"
        Me.LblGP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblGP.Visible = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.Font = New System.Drawing.Font("Verdana", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(14, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(607, 487)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = resources.GetString("Label2.Text")
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label2.Visible = False
        '
        'LblClose
        '
        Me.LblClose.BackColor = System.Drawing.Color.Black
        Me.LblClose.Font = New System.Drawing.Font("Verdana", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblClose.ForeColor = System.Drawing.Color.White
        Me.LblClose.Location = New System.Drawing.Point(14, 449)
        Me.LblClose.Name = "LblClose"
        Me.LblClose.Size = New System.Drawing.Size(607, 44)
        Me.LblClose.TabIndex = 41
        Me.LblClose.Text = "CLOSE HELP"
        Me.LblClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblClose.Visible = False
        '
        'LblWin
        '
        Me.LblWin.BackColor = System.Drawing.Color.Black
        Me.LblWin.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblWin.ForeColor = System.Drawing.Color.White
        Me.LblWin.Location = New System.Drawing.Point(13, 2)
        Me.LblWin.Name = "LblWin"
        Me.LblWin.Size = New System.Drawing.Size(607, 487)
        Me.LblWin.TabIndex = 42
        Me.LblWin.Text = "YOU DEFEATED ALL THE MATH ALIENS!" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "CONGRATULATIONS! " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.LblWin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblWin.Visible = False
        '
        'LblMenu
        '
        Me.LblMenu.BackColor = System.Drawing.Color.Black
        Me.LblMenu.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMenu.ForeColor = System.Drawing.Color.White
        Me.LblMenu.Location = New System.Drawing.Point(11, 445)
        Me.LblMenu.Name = "LblMenu"
        Me.LblMenu.Size = New System.Drawing.Size(607, 52)
        Me.LblMenu.TabIndex = 43
        Me.LblMenu.Text = "RETURN TO MAIN MENU"
        Me.LblMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblMenu.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackgroundImage = Global.WindowsApp1.My.Resources.Resources.maxresdefault
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1224, 626)
        Me.Controls.Add(Me.PanelPause)
        Me.Controls.Add(Me.LblPause)
        Me.Controls.Add(Me.LblLives)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.BPAlien)
        Me.Controls.Add(Me.BPPlayer)
        Me.Controls.Add(Me.LblStreak)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PbPlayer)
        Me.Controls.Add(Me.PbAlien)
        Me.Controls.Add(Me.LblLevel)
        Me.Controls.Add(Me.LblPrev)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ProgBar1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LblAlien)
        Me.Controls.Add(Me.LblPlayer)
        Me.Controls.Add(Me.LblQuestion)
        Me.Name = "Form1"
        Me.Text = "Multiplication Defenders!"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.PbAlien, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelPause.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblAnswer1 As Label
    Friend WithEvents LblAnswer2 As Label
    Friend WithEvents LblQuestion As Label
    Friend WithEvents LblPlayer As Label
    Friend WithEvents LblAlien As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ProgBar1 As ProgressBar
    Friend WithEvents Label3 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents LblAnswer3 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents LblPrev As Label
    Friend WithEvents LblLevel As Label
    Friend WithEvents PbAlien As PictureBox
    Friend WithEvents PbPlayer As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents LblDialog As Label
    Friend WithEvents LblStreak As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents BPPlayer As ProgressBar
    Friend WithEvents BPAlien As ProgressBar
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents LblLives As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LblPause As Label
    Friend WithEvents PanelPause As Panel
    Friend WithEvents LblResume As Label
    Friend WithEvents LblGP As Label
    Friend WithEvents LblRestart As Label
    Friend WithEvents LblExtra As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents LblClose As Label
    Friend WithEvents LblMenu As Label
    Friend WithEvents LblWin As Label
End Class
