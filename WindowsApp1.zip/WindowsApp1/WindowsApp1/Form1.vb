﻿Public Class Form1

    ' TO-DO LIST:
    ' [x] new prog bars for BP 
    ' [x] change so there is no more than 100 bp (streak... click to activate? +BP and time and then it subtract 5 from streak to begin again???)
    ' [x] check for 0 BP 
    ' [x] timer 
    ' [x] levels
    '    [x] 1
    '    [x] 2
    '    [x] 3
    '    [x] 4
    '    [x] 5
    ' [x] pause button
    ' [x] retry button
    ' [x] graphics 
    ' [x] streaks
    ' [] make it PRETTY!!!!!!!!!
    ' [x] completed game screen
    ' [x] begin game screen with
    '    [x] 1 thru 5 (easy)
    '    [x] 1 thru 12 (hard)
    '    [x] instructions panel
    ' [] key presses

    Dim Factor1 As Integer
    Dim Factor2 As Integer
    Dim PrevFactor1 As Integer
    Dim PrevFactor2 As Integer
    Dim Choice1 As Integer
    Dim Choice2 As Integer
    Dim Choice3 As Integer
    Dim Round As Integer
    Dim LevelDisplay As Integer = 1
    Dim Time As Integer
    Dim Streak As Integer
    Dim PlayerBP As Integer ' values out of range without this?? why
    Dim AlienBP As Integer
    Dim Advance As Boolean  ' checks if player can begin new level
    Dim Retry As Boolean    ' checks if player can restart from level x 
    Dim Restart As Boolean  ' checks if player can restart from beginning 
    Dim Pause As Boolean
    Dim Easy As Boolean

    Public Function Rand(ByVal Low As Long,
                         ByVal High As Long) As Long
        Rand = Int((High - Low + 1) * Rnd()) + Low
    End Function
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        LblDialog.Text = ""
        LblPrev.Text = ""
        ProgBar1.ForeColor = Color.Gold
        BPPlayer.ForeColor = Color.Green
        BPAlien.ForeColor = Color.Green
        BPAlien.Value = 100
        BPPlayer.Value = 100
        Panel1.BringToFront()
        PanelPause.Visible = True
        PanelPause.BringToFront()
        LblGP.Text = "MULTIPLICATION DEFENDERS!"
        LblRestart.Text = "BEGIN HARD GAME"
        LblResume.Text = "BEGIN EASY GAME"
        LblExtra.Text = "HELP"
        LblGP.Visible = True
        LblRestart.Visible = True
        LblResume.Visible = True
        LblExtra.Visible = True
        LblPause.Enabled = False
    End Sub

    ' SUBROUTINES:

    ' begins game (resets streak, lives, level, etc.)
    Private Sub GameRestart()
        BPAlien.Value = 100
        BPPlayer.Value = 100
        LblPlayer.Text = 100
        LblAlien.Text = 100
        BPAlien.ForeColor = Color.Green
        BPPlayer.ForeColor = Color.Green
        LevelDisplay = 1
        LblLevel.Text = 1
        LblLives.Text = 3
        Streak = 0
        LblQuestion.Text = ""
        LblPrev.Text = ""
        ProgBar1.Value = 100
        LblStreak.Text = 0
        LblDialog.Text = ""
    End Sub

    ' sets new questions and answers
    Private Sub Setup()

        ' sets question

        Time = 0
        Timer1.Enabled = True
        ProgBar1.Value = 100
        If Easy = True Then
            Factor1 = Rand(1, 5)
            Factor2 = Rand(1, 5)
        ElseIf Easy = False Then
            Factor1 = Rand(1, 12)
            Factor2 = Rand(1, 12)
        End If
        If Factor1 = PrevFactor1 And Factor2 = PrevFactor2 And Easy = True Then
            Factor1 = Rand(1, 5)
            Factor2 = Rand(1, 5)
        ElseIf Factor1 = PrevFactor1 And Factor2 = PrevFactor2 And Easy = False Then
            Factor1 = Rand(1, 12)
            Factor2 = Rand(1, 12)
        End If
        PrevFactor1 = Factor1
        PrevFactor2 = Factor2
        LblQuestion.Text = Factor1 & " x " & Factor2
        LblQuestion.Visible = True

        'sets answer choices

        Round = Rand(1, 6)
        If Easy = True Then
            Choice1 = Rand(1, 25)
            Choice2 = Rand(1, 25)
            Choice3 = Rand(1, 25)
            While Choice1 = Choice2 Or Choice1 = Choice3 Or Choice2 = Choice3
                Choice1 = Rand(1, 25)
                Choice2 = Rand(1, 25)
                Choice3 = Rand(1, 25)
            End While

            If (Round = 1 Or Round = 3 Or Round = 5 Or Round = 6) And (Choice1 = Factor1 * Factor2) Then
                Choice1 = Rand(1, 25)
            ElseIf Round = 2 Or Round = 4 Then
                Choice1 = Factor1 * Factor2
            End If
            LblAnswer1.Text = Choice1
            LblAnswer1.BringToFront()
            LblAnswer1.Visible = True

            If (Round = 2 Or Round = 4 Or Round = 5 Or Round = 6) And (Choice2 = Factor1 * Factor2) Then
                Choice2 = Rand(1, 25)
                While Choice1 = Choice2
                    Choice2 = Rand(1, 25)
                End While
            ElseIf Round = 3 Or Round = 1 Then
                Choice2 = Factor1 * Factor2
            End If
            LblAnswer2.Text = Choice2
            LblAnswer2.BringToFront()
            LblAnswer2.Visible = True

            If (Round = 1 Or Round = 2 Or Round = 3 Or Round = 4) And (Choice3 = Factor1 * Factor2) Then
                Choice3 = Rand(1, 25)
                While Choice3 = Choice1 Or Choice3 = Choice2
                    Choice3 = Rand(1, 25)
                End While
            ElseIf Round = 5 Or Round = 6 Then
                Choice3 = Factor1 * Factor2
            End If
            LblAnswer3.Text = Choice3
            LblAnswer3.BringToFront()
            LblAnswer3.Visible = True

        ElseIf Easy = False Then
            Choice1 = Rand(1, 144)
            Choice2 = Rand(1, 144)
            Choice3 = Rand(1, 144)
            While Choice1 = Choice2 Or Choice1 = Choice3 Or Choice2 = Choice3
                Choice1 = Rand(1, 144)
                Choice2 = Rand(1, 144)
                Choice3 = Rand(1, 144)
            End While

            If (Round = 1 Or Round = 3 Or Round = 5 Or Round = 6) And (Choice1 = Factor1 * Factor2) Then
                Choice1 = Rand(1, 144)
            ElseIf Round = 2 Or Round = 4 Then
                Choice1 = Factor1 * Factor2
            End If
            LblAnswer1.Text = Choice1
            LblAnswer1.BringToFront()
            LblAnswer1.Visible = True

            If (Round = 2 Or Round = 4 Or Round = 5 Or Round = 6) And (Choice2 = Factor1 * Factor2) Then
                Choice2 = Rand(1, 144)
                While Choice1 = Choice2
                    Choice2 = Rand(1, 144)
                End While
            ElseIf Round = 3 Or Round = 1 Then
                Choice2 = Factor1 * Factor2
            End If
            LblAnswer2.Text = Choice2
            LblAnswer2.BringToFront()
            LblAnswer2.Visible = True

            If (Round = 1 Or Round = 2 Or Round = 3 Or Round = 4) And (Choice3 = Factor1 * Factor2) Then
                Choice3 = Rand(1, 144)
                While Choice3 = Choice1 Or Choice3 = Choice2
                    Choice3 = Rand(1, 144)
                End While
            ElseIf Round = 5 Or Round = 6 Then
                Choice3 = Factor1 * Factor2
            End If
            LblAnswer3.Text = Choice3
            LblAnswer3.BringToFront()
            LblAnswer3.Visible = True
        End If
    End Sub

    ' checks for level end
    Private Sub Check()
        If LblPlayer.Text = 0 And Not LblLives.Text = 0 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Math Alien defeated you! Click here to retry from level " & LevelDisplay & "!"
            Timer1.Enabled = False
            LblAnswer1.Visible = False
            LblAnswer2.Visible = False
            LblAnswer3.Visible = False
            LblQuestion.Visible = False
            Retry = True
        ElseIf LblPlayer.Text = 0 And LblLives.Text = 0 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Math Alien defeated you! Better luck next time!"
            Timer1.Enabled = False
            LblAnswer1.Visible = False
            LblAnswer2.Visible = False
            LblAnswer3.Visible = False
            LblQuestion.Visible = False
            PanelPause.Visible = True
            PanelPause.BringToFront()
            LblGP.Text = "GAME OVER"
            LblGP.Visible = True
            LblMenu.Visible = True
            LblPause.Enabled = False
            Restart = True
        ElseIf LblAlien.Text = 0 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Way to go! You defeated a Math Alien! Click here to advance!"
            Timer1.Enabled = False
            LblAnswer1.Visible = False
            LblAnswer2.Visible = False
            LblAnswer3.Visible = False
            LblQuestion.Visible = False
            Advance = True ' allows player to start next level
            LevelDisplay += 1
            If LevelDisplay > 5 Then           ' win screen 
                LblAnswer1.Visible = False
                LblAnswer2.Visible = False
                LblAnswer3.Visible = False
                ProgBar1.Value = 100
                LblStreak.Text = 0
                LblDialog.Text = ""
                LblPause.Enabled = False
                PanelPause.Visible = True
                PanelPause.BringToFront()
                LblWin.Visible = True
                LblMenu.Visible = True
                LblMenu.BringToFront()
            Else LblLevel.Text = LevelDisplay
            End If
        End If
        LblPrev.Text = ": " & PrevFactor1 & " x " & PrevFactor2
    End Sub

    ' sets up restart from current level 
    Private Sub RestartLevel()
        LblLives.Text = CInt(LblLives.Text) - 1
        LblDialog.Text = ""
        LblAlien.Text = 100
        BPAlien.Value = 100
        BPAlien.ForeColor = Color.Green
        LblPlayer.Text = 100
        BPPlayer.Value = 100
        BPPlayer.ForeColor = Color.Green
        Streak = 0
        LblStreak.Text = 0
        Setup()
        Retry = False
    End Sub

    ' checks for streaks (adds to player/subtracts from alien, refills time) 
    ' checks if player can be added to / checks if alien can be subtracted from
    Private Sub StreakCheck()
        If Streak = 5 And CInt(LblPlayer.Text) <= 95 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Great multiplication! +5 BP!"
            LblPlayer.Text = CInt(LblPlayer.Text) + 5
        ElseIf Streak = 5 And CInt(LblPlayer.Text) > 95 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Great multiplication! Math Alien lost 5 BP!"
            LblAlien.Text = CInt(LblAlien.Text) - 5

        ElseIf Streak = 10 And CInt(LblPlayer.Text) <= 90 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Awesome job! +10 BP!"
            LblPlayer.Text = CInt(LblPlayer.Text) + 10
        ElseIf Streak = 10 And CInt(LblPlayer.Text) > 90 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Awesome job! Math Alien lost 10 BP!"
            LblAlien.Text = CInt(LblAlien.Text) - 10

        ElseIf Streak = 15 And LblLives.Text = 0 Then
            LblLives.Text = 1
            LblDialog.ForeColor = Color.Yellow
            ProgBar1.Value = 100
            LblDialog.Text = "Bonus! Keep multiplying! +1 life!"
        ElseIf Streak = 15 And CInt(LblPlayer.Text) <= 90 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Keep multiplying! +10 BP!"
            ProgBar1.Value = 100
            LblPlayer.Text = CInt(LblPlayer.Text) + 10
        ElseIf Streak = 15 And CInt(LblPlayer.Text) <= 90 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Keep multiplying! Math Alien lost 10 BP!"
            ProgBar1.Value = 100
            LblAlien.Text = CInt(LblAlien.Text) - 10

        ElseIf Streak = 20 And LblLives.Text = 0 Then
            LblLives.Text = 1
            LblDialog.ForeColor = Color.Yellow
            ProgBar1.Value = 100
            LblDialog.Text = "Bonus! Great work! +1 life!"
        ElseIf Streak = 20 And CInt(LblPlayer.Text) <= 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Great work! +15 BP!"
            LblPlayer.Text = CInt(LblPlayer.Text) + 15
            ProgBar1.Value = 100
        ElseIf Streak = 20 And CInt(LblPlayer.Text) > 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! Great work! Math Alien lost 15 BP!"
            LblAlien.Text = CInt(LblAlien.Text) - 15
            ProgBar1.Value = 100

        ElseIf Streak = 25 And CInt(LblPlayer.Text) <= 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100
        ElseIf Streak = 25 And CInt(LblPlayer.Text) > 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100

        ElseIf Streak = 35 And CInt(LblPlayer.Text) <= 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100
        ElseIf Streak = 35 And CInt(LblPlayer.Text) > 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100

        ElseIf Streak = 50 And CInt(LblPlayer.Text) <= 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100
        ElseIf Streak = 50 And CInt(LblPlayer.Text) > 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100

        ElseIf Streak = 100 And CInt(LblPlayer.Text) <= 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100
        ElseIf Streak = 100 And CInt(LblPlayer.Text) > 85 Then
            LblDialog.ForeColor = Color.Yellow
            LblDialog.Text = "Bonus! You're a multiplication whiz! +1 life!"
            LblLives.Text = CInt(LblLives.Text) + 1
            ProgBar1.Value = 100
        End If
    End Sub

    ' adjusts player bar
    Private Sub PlayerBar()
        ' is the number in range (label 0 - 100)
        If Advance = False Then
            If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                If CInt(LblPlayer.Text) - 10 < 0 Then
                    LblPlayer.Text = 0
                Else
                    PlayerBP = CInt(LblPlayer.Text) - 10
                    LblPlayer.Text = PlayerBP
                End If
            ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                If CInt(LblPlayer.Text) - 20 < 0 Then
                    LblPlayer.Text = 0
                Else
                    PlayerBP = CInt(LblPlayer.Text) - 20
                    LblPlayer.Text = PlayerBP
                End If
            End If
            ' is the value in range (prog bar 0 - 100)
            If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                If BPPlayer.Value - 10 < 0 Then
                    BPPlayer.Value = 0
                Else BPPlayer.Value = BPPlayer.Value - 10
                End If
            ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                If BPPlayer.Value - 20 < 0 Then
                    BPPlayer.Value = 0
                Else BPPlayer.Value = BPPlayer.Value - 20
                End If
            End If
        End If
        ' change colour
        If BPPlayer.Value <= 20 Then
            BPPlayer.ForeColor = Color.Red
        ElseIf BPPlayer.Value <= 50 Then
            BPPlayer.ForeColor = Color.Yellow
        Else BPPlayer.ForeColor = Color.Green
        End If
    End Sub

    ' adjusts alien bar
    Private Sub AlienBar()
        ' is the number in range (label)
        If Advance = False Then
            If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                If CInt(LblAlien.Text) - 10 < 0 Then
                    LblAlien.Text = 0
                Else
                    AlienBP = CInt(LblAlien.Text) - 10
                    LblAlien.Text = AlienBP
                End If
            ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                If CInt(LblAlien.Text) - 5 < 0 Then
                    LblAlien.Text = 0
                Else
                    AlienBP = CInt(LblAlien.Text) - 5
                    LblAlien.Text = AlienBP
                End If
            End If
            ' is the value in range (prog bar)
            If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                If BPAlien.Value - 10 < 0 Then
                    BPAlien.Value = 0
                Else BPAlien.Value = BPAlien.Value - 10
                End If
            ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                If BPAlien.Value - 5 < 0 Then
                    BPAlien.Value = 0
                Else BPAlien.Value = BPAlien.Value - 5
                End If
            End If
        End If
        ' changes colour 
        If BPAlien.Value <= 20 Then
            BPAlien.ForeColor = Color.Red
        ElseIf BPAlien.Value <= 50 Then
            BPAlien.ForeColor = Color.Yellow
        Else BPAlien.ForeColor = Color.Green
        End If
    End Sub

    ' handles on panel&label clicks 
    Private Sub Click1()
        ' CORRECT ANSWER 
        If Pause = False Then
            If CInt(LblAnswer1.Text) = Factor1 * Factor2 Then
                ' 1-3 (10) 4-5 (5)
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Great job! Math Alien lost 10 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Great job! Math Alien lost 5 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                End If
                ' WRONG ANSWERS: 
            ElseIf Not CInt(LblAnswer1.Text) = Factor1 * Factor2 Then
                ' 1-3 (10) 4-5 (20)
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 10 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 20 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                End If
            Else MsgBox("Unexpected!")
            End If
            Check()
            If Not Timer1.Enabled = False Then
                Setup()
            End If
        End If
    End Sub
    Private Sub Click2()
        If Pause = False Then
            If CInt(LblAnswer2.Text) = Factor1 * Factor2 Then
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Nice! Math Alien lost 10 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Awesome job! Math Alien lost 5 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                End If
            ElseIf Not CInt(LblAnswer2.Text) = Factor1 * Factor2 Then
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 10 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 20 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                End If
            Else MsgBox("Unexpected!")
            End If
            Check()
            If Not Timer1.Enabled = False Then
                Setup()
            End If
        End If
    End Sub
    Private Sub Click3()
        If Pause = False Then
            If CInt(LblAnswer3.Text) = Factor1 * Factor2 Then
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Way to go! Math Alien lost 10 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    LblDialog.Text = "Way to go! Math Alien lost 5 BP! Keep multiplying!"
                    Streak += 1
                    LblStreak.Text = Streak
                    StreakCheck()
                    AlienBar()
                End If
            ElseIf Not CInt(LblAnswer3.Text) = Factor1 * Factor2 Then
                If LevelDisplay = 1 Or LevelDisplay = 2 Or LevelDisplay = 3 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 10 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                ElseIf LevelDisplay = 4 Or LevelDisplay = 5 Then
                    LblDialog.ForeColor = Color.White
                    PlayerBar()
                    LblDialog.Text = "Yikes! You lost 20 BP! Math Alien calculates the product to be " & Factor1 * Factor2 & "!"
                    Streak = 0
                    LblStreak.Text = 0
                End If
            Else MsgBox("Unexpected!")
            End If
            Check()
            If Not Timer1.Enabled = False Then
                Setup()
            End If
        End If
    End Sub

    ' ANSWER CLICKS:

    Private Sub Panel1_Click(sender As Object, e As EventArgs) Handles Panel1.Click
        If Timer1.Enabled = True Then
            Click1()
        End If
    End Sub
    Private Sub LblAnswer1_Click(sender As Object, e As EventArgs) Handles LblAnswer1.Click
        If Timer1.Enabled = True Then
            Click1()
        End If
    End Sub
    Private Sub Panel2_Click(sender As Object, e As EventArgs) Handles Panel2.Click
        If Timer1.Enabled = True Then
            Click2()
        End If
    End Sub
    Private Sub LblAnswer2_Click(sender As Object, e As EventArgs) Handles LblAnswer2.Click
        If Timer1.Enabled = True Then
            Click2()
        End If
    End Sub
    Private Sub Panel3_Click(sender As Object, e As EventArgs) Handles Panel3.Click
        If Timer1.Enabled = True Then
            Click3()
        End If
    End Sub
    Private Sub LblAnswer3_Click(sender As Object, e As EventArgs) Handles LblAnswer3.Click
        If Timer1.Enabled = True Then
            Click3()
        End If
    End Sub

    ' ticks down per round, subtracts if time runs out (progbar1 is the time bar)
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Time += 1
        If LevelDisplay = 1 Then
            ProgBar1.Value = ProgBar1.Value - 5
            If ProgBar1.Value = 0 Then
                Timer1.Enabled = False
                PlayerBar()
                LblDialog.ForeColor = Color.White
                LblDialog.Text = "You were too slow! Math alien calculated the product to be " & Factor1 * Factor2 & "!"
                Streak = 0
                LblStreak.Text = 0
                Setup()
            End If
        ElseIf LevelDisplay = 2 Then
            ProgBar1.Value = ProgBar1.Value - 10
            If ProgBar1.Value = 0 Then
                Timer1.Enabled = False
                PlayerBar()
                LblDialog.ForeColor = Color.White
                LblDialog.Text = "You were too slow! Math alien calculated the product to be " & Factor1 * Factor2 & "!"
                Streak = 0
                LblStreak.Text = 0
                Setup()
            End If
        ElseIf LevelDisplay = 3 Then
            If ProgBar1.Value - 15 < 0 Then
                ProgBar1.Value = 0
            Else ProgBar1.Value = ProgBar1.Value - 15
            End If
            If ProgBar1.Value = 0 Then
                Timer1.Enabled = False
                PlayerBar()
                LblDialog.ForeColor = Color.White
                LblDialog.Text = "You were too slow! Math alien calculated the product to be " & Factor1 * Factor2 & "!"
                Streak = 0
                LblStreak.Text = 0
                Setup()
            End If
        ElseIf LevelDisplay = 4 Then
            If ProgBar1.Value - 15 < 0 Then
                ProgBar1.Value = 0
            Else ProgBar1.Value = ProgBar1.Value - 15
            End If
            If ProgBar1.Value = 0 Then
                Timer1.Enabled = False
                PlayerBar()
                LblDialog.ForeColor = Color.White
                LblDialog.Text = "You were too slow! Math alien calculated the product to be " & Factor1 * Factor2 & "!"
                Streak = 0
                LblStreak.Text = 0
                Setup()
            End If
        ElseIf LevelDisplay = 5 Then
            ProgBar1.Value = ProgBar1.Value - 20
            If ProgBar1.Value = 0 Then
                Timer1.Enabled = False
                PlayerBar()
                LblDialog.ForeColor = Color.White
                LblDialog.Text = "You were too slow! Math alien calculated the product to be " & Factor1 * Factor2 & "!"
                Streak = 0
                LblStreak.Text = 0
                Setup()
            End If
        End If
    End Sub

    ' begin new level 
    Private Sub LblDialog_Click(sender As Object, e As EventArgs) Handles LblDialog.Click
        If Advance = True Then
            If CInt(LblPlayer.Text) <= 75 Then
                LblPlayer.Text = Math.Round(CInt(LblPlayer.Text) + (CInt(LblPlayer.Text) / 2))
            ElseIf CInt(LblPlayer.Text) <= 15 Then
                LblPlayer.Text = 50
            ElseIf CInt(LblPlayer.Text) > 75 And CInt(LblPlayer.Text) <= 100 Then
                LblPlayer.Text = 100
            Else LblPlayer.Text = LblPlayer.Text
            End If
            LblDialog.Text = ""
            LblAlien.Text = 100
            BPAlien.Value = 100
            BPAlien.ForeColor = Color.Green
            If CInt(LblPlayer.Text) > 100 Then
                LblPlayer.Text = 100
            End If
            BPPlayer.Value = CInt(LblPlayer.Text)
            AlienBar()
            PlayerBar()
            Setup()
            Advance = False
        ElseIf Retry = True Then
            RestartLevel()
        End If
        LblDialog.ForeColor = Color.White
    End Sub

    Private Sub LblPause_Click(sender As Object, e As EventArgs) Handles LblPause.Click
        Timer1.Enabled = False
        PanelPause.BringToFront()
        PanelPause.Visible = True
        LblGP.Text = "GAME PAUSED"
        LblResume.Text = "RESUME"
        LblRestart.Text = "RESTART CURRENT LEVEL"
        LblGP.Visible = True
        LblMenu.Visible = True
        LblResume.Visible = True
        LblRestart.Visible = True
        LblExtra.Visible = True
        Pause = True
    End Sub

    Private Sub LblResume_Click(sender As Object, e As EventArgs) Handles LblResume.Click
        If LblGP.Text = "MULTIPLICATION DEFENDERS!" Then ' begin easy game
            PanelPause.Visible = False
            LblGP.Visible = False
            LblResume.Visible = False
            LblRestart.Visible = False
            LblExtra.Visible = False
            LblPause.Enabled = True
            Easy = True
            Round = 1
            Setup()
            Pause = False
            LblPause.Enabled = True
        Else ' resume current game 
            Pause = False
            PanelPause.Visible = False
            LblGP.Visible = False
            LblResume.Visible = False
            LblRestart.Visible = False
            LblExtra.Visible = False
            LblPause.Enabled = True
            Timer1.Enabled = True
            LblAnswer1.Enabled = True
            LblAnswer2.Enabled = True
            LblAnswer3.Enabled = True
            Panel1.Enabled = True
            Panel2.Enabled = True
            Panel3.Enabled = True
        End If
    End Sub

    ' for restart on pause and easy game begin 
    Private Sub LblRestart_Click(sender As Object, e As EventArgs) Handles LblRestart.Click
        If LblGP.Text = "MULTIPLICATION DEFENDERS!" Then ' begin hard game
            PanelPause.Visible = False
            LblGP.Visible = False
            LblResume.Visible = False
            LblRestart.Visible = False
            LblExtra.Visible = False
            LblPause.Enabled = True
            Easy = False
            Round = 1
            Setup()
            Pause = False
            LblPause.Enabled = True
        ElseIf Not LblLives.Text = 0 Then ' restart current level 
            LblAnswer1.Visible = True
            LblAnswer2.Visible = True
            LblAnswer3.Visible = True
            LblAnswer1.Enabled = True
            LblAnswer2.Enabled = True
            LblAnswer3.Enabled = True
            Panel1.Enabled = True
            Panel2.Enabled = True
            Panel3.Enabled = True
            RestartLevel()
            PanelPause.Visible = False
            Pause = False
        Else ' if lives is already 0 (takes back to main menu)
            LblMenu.Visible = False
            LblWin.Visible = False
            LblGP.Text = "MULTIPLICATION DEFENDERS!"
            LblRestart.Text = "BEGIN HARD GAME"
            LblResume.Text = "BEGIN EASY GAME"
            LblExtra.Text = "HELP"
            LblGP.Visible = True
            LblRestart.Visible = True
            LblResume.Visible = True
            LblExtra.Visible = True
            LblPause.Enabled = True
            LblPause.Enabled = False
            GameRestart()
        End If
    End Sub

    ' help button
    Private Sub LblExtra_Click(sender As Object, e As EventArgs) Handles LblExtra.Click
        LblClose.Visible = True
        Label2.Visible = True
        Label2.BringToFront()
        LblClose.BringToFront()
    End Sub

    ' close help
    Private Sub LblClose_Click(sender As Object, e As EventArgs) Handles LblClose.Click
        LblClose.Visible = False
        Label2.Visible = False
    End Sub

    Private Sub LblMenu_Click(sender As Object, e As EventArgs) Handles LblMenu.Click
        LblMenu.Visible = False
        LblWin.Visible = False
        LblGP.Text = "MULTIPLICATION DEFENDERS!"
        LblRestart.Text = "BEGIN HARD GAME"
        LblResume.Text = "BEGIN EASY GAME"
        LblExtra.Text = "HELP"
        Advance = False
        LblGP.Visible = True
        LblRestart.Visible = True
        LblResume.Visible = True
        LblExtra.Visible = True
        LblPause.Enabled = True
        LblPause.Enabled = False
        GameRestart()
    End Sub
End Class
